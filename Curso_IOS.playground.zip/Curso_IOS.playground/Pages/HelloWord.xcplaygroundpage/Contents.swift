//: [Previous](@previous)

import UIKit

print("Hello Word")
