/*
 Float vs Double
 Floats são menos precisas que Doubles. Floats são precisas a até 6-7 casas decimais
 Doubles são precisas a até 15-16 casas decimais. No painel da direita, você verá que a variável Float começa a apresentar informações incorretas/
 incompletas a partir da sétima casa decimal 7.
 */

import UIKit

var floatValue: Float = 3.1415926535
var doubleValue: Double = 3.1415926535

print(floatValue)
print(doubleValue)

floatValue
doubleValue
