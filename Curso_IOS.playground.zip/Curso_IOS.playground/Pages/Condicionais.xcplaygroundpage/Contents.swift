
// BOOLEANS = TRUE E FALSE

import UIKit

//var idade: Int = 47
//var nome: String = "Andre Moraes"
//var sexoMasculino: Bool = true

// CONDICIONAIS = IF, ELSE, ELSE IF,

var nome1: String = "Andreas"
var maiorDeIdade: Bool = false // MUDANDO O BOOL ENTRE VERDADEIRO E FALSO A CONDICIONAL IRA MUDAR TB.
var sexoMasculino: Bool = false

if maiorDeIdade {
    print("\(nome1) pode tirar a carteira de motorista!!!")
} else {
    print("\(nome1) Voce ainda nao podera tirar carta!!!")
}
if sexoMasculino {
    print("\(sexoMasculino), Voce é um Homem!!!")
} else {
    print("\(sexoMasculino), Voce é uma Mulher!!!")
}
print()
// COMPARACAO

var numero1 = 30
var numero2 = 20
numero1 >= numero2
numero1 <= numero2
numero1 > numero2
numero1 < numero2

if numero1 > numero2 {
    print("\(numero1), é maior que numero 2!!")
} else {
    print("\(numero2), é maior que numero 1!!")
}

